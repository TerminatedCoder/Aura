(function () {
  const E = document.createElement("link").relList;
  if (E && E.supports && E.supports("modulepreload")) return;
  for (const A of document.querySelectorAll('link[rel="modulepreload"]')) P(A);
  new MutationObserver((A) => {
    for (const w of A)
      if (w.type === "childList")
        for (const D of w.addedNodes)
          D.tagName === "LINK" && D.rel === "modulepreload" && P(D);
  }).observe(document, { childList: !0, subtree: !0 });
  function O(A) {
    const w = {};
    return (
      A.integrity && (w.integrity = A.integrity),
      A.referrerPolicy && (w.referrerPolicy = A.referrerPolicy),
      A.crossOrigin === "use-credentials"
        ? (w.credentials = "include")
        : A.crossOrigin === "anonymous"
        ? (w.credentials = "omit")
        : (w.credentials = "same-origin"),
      w
    );
  }
  function P(A) {
    if (A.ep) return;
    A.ep = !0;
    const w = O(A);
    fetch(A.href, w);
  }
})();
var ee =
  typeof globalThis < "u"
    ? globalThis
    : typeof window < "u"
    ? window
    : typeof global < "u"
    ? global
    : typeof self < "u"
    ? self
    : {};
function Q(p) {
  return p && p.__esModule && Object.prototype.hasOwnProperty.call(p, "default")
    ? p.default
    : p;
}
var X = { exports: {} };
(function (p, E) {
  (function (O, P) {
    P(p);
  })(
    typeof globalThis < "u" ? globalThis : typeof self < "u" ? self : ee,
    function (O) {
      var P, A;
      if (
        !(
          (A = (P = globalThis.chrome) == null ? void 0 : P.runtime) != null &&
          A.id
        )
      )
        throw new Error(
          "This script should only be loaded in a browser extension."
        );
      if (
        typeof globalThis.browser > "u" ||
        Object.getPrototypeOf(globalThis.browser) !== Object.prototype
      ) {
        const w = "The message port closed before a response was received.",
          D = (y) => {
            const L = {
              alarms: {
                clear: { minArgs: 0, maxArgs: 1 },
                clearAll: { minArgs: 0, maxArgs: 0 },
                get: { minArgs: 0, maxArgs: 1 },
                getAll: { minArgs: 0, maxArgs: 0 },
              },
              bookmarks: {
                create: { minArgs: 1, maxArgs: 1 },
                get: { minArgs: 1, maxArgs: 1 },
                getChildren: { minArgs: 1, maxArgs: 1 },
                getRecent: { minArgs: 1, maxArgs: 1 },
                getSubTree: { minArgs: 1, maxArgs: 1 },
                getTree: { minArgs: 0, maxArgs: 0 },
                move: { minArgs: 2, maxArgs: 2 },
                remove: { minArgs: 1, maxArgs: 1 },
                removeTree: { minArgs: 1, maxArgs: 1 },
                search: { minArgs: 1, maxArgs: 1 },
                update: { minArgs: 2, maxArgs: 2 },
              },
              browserAction: {
                disable: { minArgs: 0, maxArgs: 1, fallbackToNoCallback: !0 },
                enable: { minArgs: 0, maxArgs: 1, fallbackToNoCallback: !0 },
                getBadgeBackgroundColor: { minArgs: 1, maxArgs: 1 },
                getBadgeText: { minArgs: 1, maxArgs: 1 },
                getPopup: { minArgs: 1, maxArgs: 1 },
                getTitle: { minArgs: 1, maxArgs: 1 },
                openPopup: { minArgs: 0, maxArgs: 0 },
                setBadgeBackgroundColor: {
                  minArgs: 1,
                  maxArgs: 1,
                  fallbackToNoCallback: !0,
                },
                setBadgeText: {
                  minArgs: 1,
                  maxArgs: 1,
                  fallbackToNoCallback: !0,
                },
                setIcon: { minArgs: 1, maxArgs: 1 },
                setPopup: { minArgs: 1, maxArgs: 1, fallbackToNoCallback: !0 },
                setTitle: { minArgs: 1, maxArgs: 1, fallbackToNoCallback: !0 },
              },
              browsingData: {
                remove: { minArgs: 2, maxArgs: 2 },
                removeCache: { minArgs: 1, maxArgs: 1 },
                removeCookies: { minArgs: 1, maxArgs: 1 },
                removeDownloads: { minArgs: 1, maxArgs: 1 },
                removeFormData: { minArgs: 1, maxArgs: 1 },
                removeHistory: { minArgs: 1, maxArgs: 1 },
                removeLocalStorage: { minArgs: 1, maxArgs: 1 },
                removePasswords: { minArgs: 1, maxArgs: 1 },
                removePluginData: { minArgs: 1, maxArgs: 1 },
                settings: { minArgs: 0, maxArgs: 0 },
              },
              commands: { getAll: { minArgs: 0, maxArgs: 0 } },
              contextMenus: {
                remove: { minArgs: 1, maxArgs: 1 },
                removeAll: { minArgs: 0, maxArgs: 0 },
                update: { minArgs: 2, maxArgs: 2 },
              },
              cookies: {
                get: { minArgs: 1, maxArgs: 1 },
                getAll: { minArgs: 1, maxArgs: 1 },
                getAllCookieStores: { minArgs: 0, maxArgs: 0 },
                remove: { minArgs: 1, maxArgs: 1 },
                set: { minArgs: 1, maxArgs: 1 },
              },
              devtools: {
                inspectedWindow: {
                  eval: { minArgs: 1, maxArgs: 2, singleCallbackArg: !1 },
                },
                panels: {
                  create: { minArgs: 3, maxArgs: 3, singleCallbackArg: !0 },
                  elements: { createSidebarPane: { minArgs: 1, maxArgs: 1 } },
                },
              },
              downloads: {
                cancel: { minArgs: 1, maxArgs: 1 },
                download: { minArgs: 1, maxArgs: 1 },
                erase: { minArgs: 1, maxArgs: 1 },
                getFileIcon: { minArgs: 1, maxArgs: 2 },
                open: { minArgs: 1, maxArgs: 1, fallbackToNoCallback: !0 },
                pause: { minArgs: 1, maxArgs: 1 },
                removeFile: { minArgs: 1, maxArgs: 1 },
                resume: { minArgs: 1, maxArgs: 1 },
                search: { minArgs: 1, maxArgs: 1 },
                show: { minArgs: 1, maxArgs: 1, fallbackToNoCallback: !0 },
              },
              extension: {
                isAllowedFileSchemeAccess: { minArgs: 0, maxArgs: 0 },
                isAllowedIncognitoAccess: { minArgs: 0, maxArgs: 0 },
              },
              history: {
                addUrl: { minArgs: 1, maxArgs: 1 },
                deleteAll: { minArgs: 0, maxArgs: 0 },
                deleteRange: { minArgs: 1, maxArgs: 1 },
                deleteUrl: { minArgs: 1, maxArgs: 1 },
                getVisits: { minArgs: 1, maxArgs: 1 },
                search: { minArgs: 1, maxArgs: 1 },
              },
              i18n: {
                detectLanguage: { minArgs: 1, maxArgs: 1 },
                getAcceptLanguages: { minArgs: 0, maxArgs: 0 },
              },
              identity: { launchWebAuthFlow: { minArgs: 1, maxArgs: 1 } },
              idle: { queryState: { minArgs: 1, maxArgs: 1 } },
              management: {
                get: { minArgs: 1, maxArgs: 1 },
                getAll: { minArgs: 0, maxArgs: 0 },
                getSelf: { minArgs: 0, maxArgs: 0 },
                setEnabled: { minArgs: 2, maxArgs: 2 },
                uninstallSelf: { minArgs: 0, maxArgs: 1 },
              },
              notifications: {
                clear: { minArgs: 1, maxArgs: 1 },
                create: { minArgs: 1, maxArgs: 2 },
                getAll: { minArgs: 0, maxArgs: 0 },
                getPermissionLevel: { minArgs: 0, maxArgs: 0 },
                update: { minArgs: 2, maxArgs: 2 },
              },
              pageAction: {
                getPopup: { minArgs: 1, maxArgs: 1 },
                getTitle: { minArgs: 1, maxArgs: 1 },
                hide: { minArgs: 1, maxArgs: 1, fallbackToNoCallback: !0 },
                setIcon: { minArgs: 1, maxArgs: 1 },
                setPopup: { minArgs: 1, maxArgs: 1, fallbackToNoCallback: !0 },
                setTitle: { minArgs: 1, maxArgs: 1, fallbackToNoCallback: !0 },
                show: { minArgs: 1, maxArgs: 1, fallbackToNoCallback: !0 },
              },
              permissions: {
                contains: { minArgs: 1, maxArgs: 1 },
                getAll: { minArgs: 0, maxArgs: 0 },
                remove: { minArgs: 1, maxArgs: 1 },
                request: { minArgs: 1, maxArgs: 1 },
              },
              runtime: {
                getBackgroundPage: { minArgs: 0, maxArgs: 0 },
                getPlatformInfo: { minArgs: 0, maxArgs: 0 },
                openOptionsPage: { minArgs: 0, maxArgs: 0 },
                requestUpdateCheck: { minArgs: 0, maxArgs: 0 },
                sendMessage: { minArgs: 1, maxArgs: 3 },
                sendNativeMessage: { minArgs: 2, maxArgs: 2 },
                setUninstallURL: { minArgs: 1, maxArgs: 1 },
              },
              sessions: {
                getDevices: { minArgs: 0, maxArgs: 1 },
                getRecentlyClosed: { minArgs: 0, maxArgs: 1 },
                restore: { minArgs: 0, maxArgs: 1 },
              },
              storage: {
                local: {
                  clear: { minArgs: 0, maxArgs: 0 },
                  get: { minArgs: 0, maxArgs: 1 },
                  getBytesInUse: { minArgs: 0, maxArgs: 1 },
                  remove: { minArgs: 1, maxArgs: 1 },
                  set: { minArgs: 1, maxArgs: 1 },
                },
                managed: {
                  get: { minArgs: 0, maxArgs: 1 },
                  getBytesInUse: { minArgs: 0, maxArgs: 1 },
                },
                sync: {
                  clear: { minArgs: 0, maxArgs: 0 },
                  get: { minArgs: 0, maxArgs: 1 },
                  getBytesInUse: { minArgs: 0, maxArgs: 1 },
                  remove: { minArgs: 1, maxArgs: 1 },
                  set: { minArgs: 1, maxArgs: 1 },
                },
              },
              tabs: {
                captureVisibleTab: { minArgs: 0, maxArgs: 2 },
                create: { minArgs: 1, maxArgs: 1 },
                detectLanguage: { minArgs: 0, maxArgs: 1 },
                discard: { minArgs: 0, maxArgs: 1 },
                duplicate: { minArgs: 1, maxArgs: 1 },
                executeScript: { minArgs: 1, maxArgs: 2 },
                get: { minArgs: 1, maxArgs: 1 },
                getCurrent: { minArgs: 0, maxArgs: 0 },
                getZoom: { minArgs: 0, maxArgs: 1 },
                getZoomSettings: { minArgs: 0, maxArgs: 1 },
                goBack: { minArgs: 0, maxArgs: 1 },
                goForward: { minArgs: 0, maxArgs: 1 },
                highlight: { minArgs: 1, maxArgs: 1 },
                insertCSS: { minArgs: 1, maxArgs: 2 },
                move: { minArgs: 2, maxArgs: 2 },
                query: { minArgs: 1, maxArgs: 1 },
                reload: { minArgs: 0, maxArgs: 2 },
                remove: { minArgs: 1, maxArgs: 1 },
                removeCSS: { minArgs: 1, maxArgs: 2 },
                sendMessage: { minArgs: 2, maxArgs: 3 },
                setZoom: { minArgs: 1, maxArgs: 2 },
                setZoomSettings: { minArgs: 1, maxArgs: 2 },
                update: { minArgs: 1, maxArgs: 2 },
              },
              topSites: { get: { minArgs: 0, maxArgs: 0 } },
              webNavigation: {
                getAllFrames: { minArgs: 1, maxArgs: 1 },
                getFrame: { minArgs: 1, maxArgs: 1 },
              },
              webRequest: {
                handlerBehaviorChanged: { minArgs: 0, maxArgs: 0 },
              },
              windows: {
                create: { minArgs: 0, maxArgs: 1 },
                get: { minArgs: 1, maxArgs: 2 },
                getAll: { minArgs: 0, maxArgs: 1 },
                getCurrent: { minArgs: 0, maxArgs: 1 },
                getLastFocused: { minArgs: 0, maxArgs: 1 },
                remove: { minArgs: 1, maxArgs: 1 },
                update: { minArgs: 2, maxArgs: 2 },
              },
            };
            if (Object.keys(L).length === 0)
              throw new Error(
                "api-metadata.json has not been included in browser-polyfill"
              );
            class b extends WeakMap {
              constructor(c, m = void 0) {
                super(m), (this.createItem = c);
              }
              get(c) {
                return (
                  this.has(c) || this.set(c, this.createItem(c)), super.get(c)
                );
              }
            }
            const v = (a) =>
                a && typeof a == "object" && typeof a.then == "function",
              x =
                (a, c) =>
                (...m) => {
                  y.runtime.lastError
                    ? a.reject(new Error(y.runtime.lastError.message))
                    : c.singleCallbackArg ||
                      (m.length <= 1 && c.singleCallbackArg !== !1)
                    ? a.resolve(m[0])
                    : a.resolve(m);
                },
              d = (a) => (a == 1 ? "argument" : "arguments"),
              $ = (a, c) =>
                function (f, ...T) {
                  if (T.length < c.minArgs)
                    throw new Error(
                      `Expected at least ${c.minArgs} ${d(
                        c.minArgs
                      )} for ${a}(), got ${T.length}`
                    );
                  if (T.length > c.maxArgs)
                    throw new Error(
                      `Expected at most ${c.maxArgs} ${d(
                        c.maxArgs
                      )} for ${a}(), got ${T.length}`
                    );
                  return new Promise((C, S) => {
                    if (c.fallbackToNoCallback)
                      try {
                        f[a](...T, x({ resolve: C, reject: S }, c));
                      } catch (u) {
                        console.warn(
                          `${a} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `,
                          u
                        ),
                          f[a](...T),
                          (c.fallbackToNoCallback = !1),
                          (c.noCallback = !0),
                          C();
                      }
                    else
                      c.noCallback
                        ? (f[a](...T), C())
                        : f[a](...T, x({ resolve: C, reject: S }, c));
                  });
                },
              F = (a, c, m) =>
                new Proxy(c, {
                  apply(f, T, C) {
                    return m.call(T, a, ...C);
                  },
                });
            let j = Function.call.bind(Object.prototype.hasOwnProperty);
            const B = (a, c = {}, m = {}) => {
                let f = Object.create(null),
                  T = {
                    has(S, u) {
                      return u in a || u in f;
                    },
                    get(S, u, _) {
                      if (u in f) return f[u];
                      if (!(u in a)) return;
                      let k = a[u];
                      if (typeof k == "function")
                        if (typeof c[u] == "function") k = F(a, a[u], c[u]);
                        else if (j(m, u)) {
                          let N = $(u, m[u]);
                          k = F(a, a[u], N);
                        } else k = k.bind(a);
                      else if (
                        typeof k == "object" &&
                        k !== null &&
                        (j(c, u) || j(m, u))
                      )
                        k = B(k, c[u], m[u]);
                      else if (j(m, "*")) k = B(k, c[u], m["*"]);
                      else
                        return (
                          Object.defineProperty(f, u, {
                            configurable: !0,
                            enumerable: !0,
                            get() {
                              return a[u];
                            },
                            set(N) {
                              a[u] = N;
                            },
                          }),
                          k
                        );
                      return (f[u] = k), k;
                    },
                    set(S, u, _, k) {
                      return u in f ? (f[u] = _) : (a[u] = _), !0;
                    },
                    defineProperty(S, u, _) {
                      return Reflect.defineProperty(f, u, _);
                    },
                    deleteProperty(S, u) {
                      return Reflect.deleteProperty(f, u);
                    },
                  },
                  C = Object.create(a);
                return new Proxy(C, T);
              },
              W = (a) => ({
                addListener(c, m, ...f) {
                  c.addListener(a.get(m), ...f);
                },
                hasListener(c, m) {
                  return c.hasListener(a.get(m));
                },
                removeListener(c, m) {
                  c.removeListener(a.get(m));
                },
              }),
              q = new b((a) =>
                typeof a != "function"
                  ? a
                  : function (m) {
                      const f = B(
                        m,
                        {},
                        { getContent: { minArgs: 0, maxArgs: 0 } }
                      );
                      a(f);
                    }
              ),
              Z = new b((a) =>
                typeof a != "function"
                  ? a
                  : function (m, f, T) {
                      let C = !1,
                        S,
                        u = new Promise((n) => {
                          S = function (t) {
                            (C = !0), n(t);
                          };
                        }),
                        _;
                      try {
                        _ = a(m, f, S);
                      } catch (n) {
                        _ = Promise.reject(n);
                      }
                      const k = _ !== !0 && v(_);
                      if (_ !== !0 && !k && !C) return !1;
                      const N = (n) => {
                        n.then(
                          (t) => {
                            T(t);
                          },
                          (t) => {
                            let o;
                            t &&
                            (t instanceof Error || typeof t.message == "string")
                              ? (o = t.message)
                              : (o = "An unexpected error occurred"),
                              T({
                                __mozWebExtensionPolyfillReject__: !0,
                                message: o,
                              });
                          }
                        ).catch((t) => {
                          console.error(
                            "Failed to send onMessage rejected reply",
                            t
                          );
                        });
                      };
                      return N(k ? _ : u), !0;
                    }
              ),
              U = ({ reject: a, resolve: c }, m) => {
                y.runtime.lastError
                  ? y.runtime.lastError.message === w
                    ? c()
                    : a(new Error(y.runtime.lastError.message))
                  : m && m.__mozWebExtensionPolyfillReject__
                  ? a(new Error(m.message))
                  : c(m);
              },
              z = (a, c, m, ...f) => {
                if (f.length < c.minArgs)
                  throw new Error(
                    `Expected at least ${c.minArgs} ${d(
                      c.minArgs
                    )} for ${a}(), got ${f.length}`
                  );
                if (f.length > c.maxArgs)
                  throw new Error(
                    `Expected at most ${c.maxArgs} ${d(
                      c.maxArgs
                    )} for ${a}(), got ${f.length}`
                  );
                return new Promise((T, C) => {
                  const S = U.bind(null, { resolve: T, reject: C });
                  f.push(S), m.sendMessage(...f);
                });
              },
              H = {
                devtools: { network: { onRequestFinished: W(q) } },
                runtime: {
                  onMessage: W(Z),
                  onMessageExternal: W(Z),
                  sendMessage: z.bind(null, "sendMessage", {
                    minArgs: 1,
                    maxArgs: 3,
                  }),
                },
                tabs: {
                  sendMessage: z.bind(null, "sendMessage", {
                    minArgs: 2,
                    maxArgs: 3,
                  }),
                },
              },
              V = {
                clear: { minArgs: 1, maxArgs: 1 },
                get: { minArgs: 1, maxArgs: 1 },
                set: { minArgs: 1, maxArgs: 1 },
              };
            return (
              (L.privacy = {
                network: { "*": V },
                services: { "*": V },
                websites: { "*": V },
              }),
              B(y, H, L)
            );
          };
        O.exports = D(chrome);
      } else O.exports = globalThis.browser;
    }
  );
})(X);
var te = X.exports;
const R = Q(te);
async function ne(p) {
  let E = await chrome.storage.local.get([p]);
  if (E.hasOwnProperty(p)) return E[p];
}
async function re(p) {
  let E = await chrome.storage.local.get([p]);
  return E.hasOwnProperty(p) ? E[p] : !0;
}
async function se(p) {
  let E = await chrome.storage.local.get([p]);
  return E.hasOwnProperty(p) ? E[p] : "";
}
var Y = { exports: {} };
(function (p, E) {
  (function (O, P) {
    p.exports = P();
  })(self, function () {
    return (() => {
      var O = {
          d: (n, t) => {
            for (var o in t)
              O.o(t, o) &&
                !O.o(n, o) &&
                Object.defineProperty(n, o, { enumerable: !0, get: t[o] });
          },
          o: (n, t) => Object.prototype.hasOwnProperty.call(n, t),
          r: (n) => {
            typeof Symbol < "u" &&
              Symbol.toStringTag &&
              Object.defineProperty(n, Symbol.toStringTag, { value: "Module" }),
              Object.defineProperty(n, "__esModule", { value: !0 });
          },
        },
        P = {};
      function A(n) {
        return (
          (A =
            typeof Symbol == "function" && typeof Symbol.iterator == "symbol"
              ? function (t) {
                  return typeof t;
                }
              : function (t) {
                  return t &&
                    typeof Symbol == "function" &&
                    t.constructor === Symbol &&
                    t !== Symbol.prototype
                    ? "symbol"
                    : typeof t;
                }),
          A(n)
        );
      }
      function w(n, t) {
        if (!(n instanceof t))
          throw new TypeError("Cannot call a class as a function");
      }
      function D(n, t) {
        for (var o = 0; o < t.length; o++) {
          var e = t[o];
          (e.enumerable = e.enumerable || !1),
            (e.configurable = !0),
            "value" in e && (e.writable = !0),
            Object.defineProperty(n, e.key, e);
        }
      }
      O.r(P), O.d(P, { default: () => N });
      var y = {
          maxNotifications: 10,
          animationDuration: 300,
          position: "bottom-right",
          labels: {
            tip: "Tip",
            info: "Info",
            success: "Success",
            warning: "Attention",
            alert: "Error",
            async: "Loading",
            confirm: "Confirmation required",
            confirmOk: "OK",
            confirmCancel: "Cancel",
          },
          icons: {
            tip: "question-circle",
            info: "info-circle",
            success: "check-circle",
            warning: "exclamation-circle",
            alert: "exclamation-triangle",
            async: "cog fa-spin",
            confirm: "exclamation-triangle",
            prefix: "<i class='fa fas fa-fw fa-",
            suffix: "'></i>",
            enabled: !0,
          },
          replacements: {
            tip: null,
            info: null,
            success: null,
            warning: null,
            alert: null,
            async: null,
            "async-block": null,
            modal: null,
            confirm: null,
            general: { "<script>": "", "</script>": "" },
          },
          messages: {
            tip: "",
            info: "",
            success: "Action has been succeeded",
            warning: "",
            alert: "Action has been failed",
            confirm: "This action can't be undone. Continue?",
            async: "Please, wait...",
            "async-block": "Loading",
          },
          formatError: function (n) {
            if (n.response) {
              if (!n.response.data) return "500 API Server Error";
              if (n.response.data.errors)
                return n.response.data.errors
                  .map(function (t) {
                    return t.detail;
                  })
                  .join("<br>");
              if (n.response.statusText)
                return ""
                  .concat(n.response.status, " ")
                  .concat(n.response.statusText, ": ")
                  .concat(n.response.data);
            }
            return n.message ? n.message : n;
          },
          durations: {
            global: 5e3,
            success: null,
            info: null,
            tip: null,
            warning: null,
            alert: null,
          },
          minDurations: { async: 1e3, "async-block": 1e3 },
        },
        L = (function () {
          function n() {
            var e =
                arguments.length > 0 && arguments[0] !== void 0
                  ? arguments[0]
                  : {},
              i =
                arguments.length > 1 && arguments[1] !== void 0
                  ? arguments[1]
                  : y;
            w(this, n), Object.assign(this, this.defaultsDeep(i, e));
          }
          var t, o;
          return (
            (t = n),
            (o = [
              {
                key: "icon",
                value: function (e) {
                  return this.icons.enabled
                    ? ""
                        .concat(this.icons.prefix)
                        .concat(this.icons[e])
                        .concat(this.icons.suffix)
                    : "";
                },
              },
              {
                key: "label",
                value: function (e) {
                  return this.labels[e];
                },
              },
              {
                key: "duration",
                value: function (e) {
                  var i = this.durations[e];
                  return i === null ? this.durations.global : i;
                },
              },
              {
                key: "toSecs",
                value: function (e) {
                  return "".concat(e / 1e3, "s");
                },
              },
              {
                key: "applyReplacements",
                value: function (e, i) {
                  if (!e) return this.messages[i] || "";
                  for (var g = 0, l = ["general", i]; g < l.length; g++) {
                    var r = l[g];
                    if (this.replacements[r])
                      for (var s in this.replacements[r])
                        e = e.replace(s, this.replacements[r][s]);
                  }
                  return e;
                },
              },
              {
                key: "override",
                value: function (e) {
                  return e ? new n(e, this) : this;
                },
              },
              {
                key: "defaultsDeep",
                value: function (e, i) {
                  var g = {};
                  for (var l in e)
                    i.hasOwnProperty(l)
                      ? (g[l] =
                          A(e[l]) === "object" && e[l] !== null
                            ? this.defaultsDeep(e[l], i[l])
                            : i[l])
                      : (g[l] = e[l]);
                  return g;
                },
              },
            ]),
            o && D(t.prototype, o),
            n
          );
        })(),
        b = "awn",
        v = {
          popup: "".concat(b, "-popup"),
          toast: "".concat(b, "-toast"),
          btn: "".concat(b, "-btn"),
          confirm: "".concat(b, "-confirm"),
        },
        x = {
          prefix: v.toast,
          klass: {
            label: "".concat(v.toast, "-label"),
            content: "".concat(v.toast, "-content"),
            icon: "".concat(v.toast, "-icon"),
            progressBar: "".concat(v.toast, "-progress-bar"),
            progressBarPause: "".concat(v.toast, "-progress-bar-paused"),
          },
          ids: { container: "".concat(v.toast, "-container") },
        },
        d = {
          prefix: v.popup,
          klass: {
            buttons: "".concat(b, "-buttons"),
            button: v.btn,
            successBtn: "".concat(v.btn, "-success"),
            cancelBtn: "".concat(v.btn, "-cancel"),
            title: "".concat(v.popup, "-title"),
            body: "".concat(v.popup, "-body"),
            content: "".concat(v.popup, "-content"),
            auraAnimation: "".concat(v.popup, "-loading-auras"),
          },
          ids: {
            wrapper: "".concat(v.popup, "-wrapper"),
            confirmOk: "".concat(v.confirm, "-ok"),
            confirmCancel: "".concat(v.confirm, "-cancel"),
          },
        },
        $ = { klass: { hiding: "".concat(b, "-hiding") }, lib: b };
      function F(n, t) {
        for (var o = 0; o < t.length; o++) {
          var e = t[o];
          (e.enumerable = e.enumerable || !1),
            (e.configurable = !0),
            "value" in e && (e.writable = !0),
            Object.defineProperty(n, e.key, e);
        }
      }
      var j = (function () {
        function n(e, i, g, l, r) {
          (function (s, h) {
            if (!(s instanceof h))
              throw new TypeError("Cannot call a class as a function");
          })(this, n),
            (this.newNode = document.createElement("div")),
            i && (this.newNode.id = i),
            g && (this.newNode.className = g),
            l && (this.newNode.style.cssText = l),
            (this.parent = e),
            (this.options = r);
        }
        var t, o;
        return (
          (t = n),
          (o = [
            { key: "beforeInsert", value: function () {} },
            { key: "afterInsert", value: function () {} },
            {
              key: "insert",
              value: function () {
                return (
                  this.beforeInsert(),
                  (this.el = this.parent.appendChild(this.newNode)),
                  this.afterInsert(),
                  this
                );
              },
            },
            {
              key: "replace",
              value: function (e) {
                var i = this;
                if (this.getElement())
                  return this.beforeDelete().then(function () {
                    return (
                      i.updateType(e.type),
                      i.parent.replaceChild(e.newNode, i.el),
                      (i.el = i.getElement(e.newNode)),
                      i.afterInsert(),
                      i
                    );
                  });
              },
            },
            {
              key: "beforeDelete",
              value: function () {
                var e = this,
                  i =
                    arguments.length > 0 && arguments[0] !== void 0
                      ? arguments[0]
                      : this.el,
                  g = 0;
                return (
                  this.start &&
                    (g =
                      this.options.minDurations[this.type] +
                      this.start -
                      Date.now()) < 0 &&
                    (g = 0),
                  new Promise(function (l) {
                    setTimeout(function () {
                      i.classList.add($.klass.hiding),
                        setTimeout(l, e.options.animationDuration);
                    }, g);
                  })
                );
              },
            },
            {
              key: "delete",
              value: function () {
                var e = this,
                  i =
                    arguments.length > 0 && arguments[0] !== void 0
                      ? arguments[0]
                      : this.el;
                return this.getElement(i)
                  ? this.beforeDelete(i).then(function () {
                      i.remove(), e.afterDelete();
                    })
                  : null;
              },
            },
            { key: "afterDelete", value: function () {} },
            {
              key: "getElement",
              value: function () {
                var e =
                  arguments.length > 0 && arguments[0] !== void 0
                    ? arguments[0]
                    : this.el;
                return e ? document.getElementById(e.id) : null;
              },
            },
            {
              key: "addEvent",
              value: function (e, i) {
                this.el.addEventListener(e, i);
              },
            },
            {
              key: "toggleClass",
              value: function (e) {
                this.el.classList.toggle(e);
              },
            },
            {
              key: "updateType",
              value: function (e) {
                (this.type = e),
                  (this.duration = this.options.duration(this.type));
              },
            },
          ]),
          o && F(t.prototype, o),
          n
        );
      })();
      function B(n, t) {
        for (var o = 0; o < t.length; o++) {
          var e = t[o];
          (e.enumerable = e.enumerable || !1),
            (e.configurable = !0),
            "value" in e && (e.writable = !0),
            Object.defineProperty(n, e.key, e);
        }
      }
      var W = (function () {
        function n(e, i) {
          (function (g, l) {
            if (!(g instanceof l))
              throw new TypeError("Cannot call a class as a function");
          })(this, n),
            (this.callback = e),
            (this.remaining = i),
            this.resume();
        }
        var t, o;
        return (
          (t = n),
          (o = [
            {
              key: "pause",
              value: function () {
                (this.paused = !0),
                  window.clearTimeout(this.timerId),
                  (this.remaining -= new Date() - this.start);
              },
            },
            {
              key: "resume",
              value: function () {
                var e = this;
                (this.paused = !1),
                  (this.start = new Date()),
                  window.clearTimeout(this.timerId),
                  (this.timerId = window.setTimeout(function () {
                    window.clearTimeout(e.timerId), e.callback();
                  }, this.remaining));
              },
            },
            {
              key: "toggle",
              value: function () {
                this.paused ? this.resume() : this.pause();
              },
            },
          ]) && B(t.prototype, o),
          n
        );
      })();
      function q(n) {
        return (
          (q =
            typeof Symbol == "function" && typeof Symbol.iterator == "symbol"
              ? function (t) {
                  return typeof t;
                }
              : function (t) {
                  return t &&
                    typeof Symbol == "function" &&
                    t.constructor === Symbol &&
                    t !== Symbol.prototype
                    ? "symbol"
                    : typeof t;
                }),
          q(n)
        );
      }
      function Z(n, t) {
        for (var o = 0; o < t.length; o++) {
          var e = t[o];
          (e.enumerable = e.enumerable || !1),
            (e.configurable = !0),
            "value" in e && (e.writable = !0),
            Object.defineProperty(n, e.key, e);
        }
      }
      function U(n, t) {
        return (
          (U =
            Object.setPrototypeOf ||
            function (o, e) {
              return (o.__proto__ = e), o;
            }),
          U(n, t)
        );
      }
      function z(n, t) {
        if (t && (q(t) === "object" || typeof t == "function")) return t;
        if (t !== void 0)
          throw new TypeError(
            "Derived constructors may only return object or undefined"
          );
        return (function (o) {
          if (o === void 0)
            throw new ReferenceError(
              "this hasn't been initialised - super() hasn't been called"
            );
          return o;
        })(n);
      }
      function H(n) {
        return (
          (H = Object.setPrototypeOf
            ? Object.getPrototypeOf
            : function (t) {
                return t.__proto__ || Object.getPrototypeOf(t);
              }),
          H(n)
        );
      }
      var V = (function (n) {
        (function (r, s) {
          if (typeof s != "function" && s !== null)
            throw new TypeError(
              "Super expression must either be null or a function"
            );
          (r.prototype = Object.create(s && s.prototype, {
            constructor: { value: r, writable: !0, configurable: !0 },
          })),
            s && U(r, s);
        })(l, n);
        var t,
          o,
          e,
          i,
          g =
            ((e = l),
            (i = (function () {
              if (
                typeof Reflect > "u" ||
                !Reflect.construct ||
                Reflect.construct.sham
              )
                return !1;
              if (typeof Proxy == "function") return !0;
              try {
                return (
                  Boolean.prototype.valueOf.call(
                    Reflect.construct(Boolean, [], function () {})
                  ),
                  !0
                );
              } catch {
                return !1;
              }
            })()),
            function () {
              var r,
                s = H(e);
              if (i) {
                var h = H(this).constructor;
                r = Reflect.construct(s, arguments, h);
              } else r = s.apply(this, arguments);
              return z(this, r);
            });
        function l(r, s, h, I) {
          var K;
          return (
            (function (G, J) {
              if (!(G instanceof J))
                throw new TypeError("Cannot call a class as a function");
            })(this, l),
            (K = g.call(
              this,
              I,
              ""
                .concat(x.prefix, "-")
                .concat(Math.floor(Date.now() - 100 * Math.random())),
              "".concat(x.prefix, " ").concat(x.prefix, "-").concat(s),
              "animation-duration: ".concat(h.toSecs(h.animationDuration), ";"),
              h
            )).updateType(s),
            K.setInnerHtml(r),
            K
          );
        }
        return (
          (t = l),
          (o = [
            {
              key: "setInnerHtml",
              value: function (r) {
                this.type === "alert" && r && (r = this.options.formatError(r)),
                  (r = this.options.applyReplacements(r, this.type)),
                  (this.newNode.innerHTML = '<div class="awn-toast-wrapper">'
                    .concat(this.progressBar)
                    .concat(this.label, '<div class="')
                    .concat(x.klass.content, '">')
                    .concat(r, '</div><span class="')
                    .concat(x.klass.icon, '">')
                    .concat(this.options.icon(this.type), "</span></div>"));
              },
            },
            {
              key: "beforeInsert",
              value: function () {
                var r = this;
                if (
                  this.parent.childElementCount >= this.options.maxNotifications
                ) {
                  var s = Array.from(
                    this.parent.getElementsByClassName(x.prefix)
                  );
                  this.delete(
                    s.find(function (h) {
                      return !r.isDeleted(h);
                    })
                  );
                }
              },
            },
            {
              key: "afterInsert",
              value: function () {
                var r = this;
                if (this.type == "async") return (this.start = Date.now());
                if (
                  (this.addEvent("click", function () {
                    return r.delete();
                  }),
                  !(this.duration <= 0))
                ) {
                  this.timer = new W(function () {
                    return r.delete();
                  }, this.duration);
                  for (
                    var s = 0, h = ["mouseenter", "mouseleave"];
                    s < h.length;
                    s++
                  ) {
                    var I = h[s];
                    this.addEvent(I, function () {
                      r.isDeleted() ||
                        (r.toggleClass(x.klass.progressBarPause),
                        r.timer.toggle());
                    });
                  }
                }
              },
            },
            {
              key: "isDeleted",
              value: function () {
                var r =
                  arguments.length > 0 && arguments[0] !== void 0
                    ? arguments[0]
                    : this.el;
                return r.classList.contains($.klass.hiding);
              },
            },
            {
              key: "progressBar",
              get: function () {
                return this.duration <= 0 || this.type === "async"
                  ? ""
                  : "<div class='"
                      .concat(
                        x.klass.progressBar,
                        `' style="animation-duration:`
                      )
                      .concat(this.options.toSecs(this.duration), ';"></div>');
              },
            },
            {
              key: "label",
              get: function () {
                return '<b class="'
                  .concat(x.klass.label, '">')
                  .concat(this.options.label(this.type), "</b>");
              },
            },
          ]),
          o && Z(t.prototype, o),
          l
        );
      })(j);
      function a(n) {
        return (
          (a =
            typeof Symbol == "function" && typeof Symbol.iterator == "symbol"
              ? function (t) {
                  return typeof t;
                }
              : function (t) {
                  return t &&
                    typeof Symbol == "function" &&
                    t.constructor === Symbol &&
                    t !== Symbol.prototype
                    ? "symbol"
                    : typeof t;
                }),
          a(n)
        );
      }
      function c(n, t) {
        if (!(n instanceof t))
          throw new TypeError("Cannot call a class as a function");
      }
      function m(n, t) {
        for (var o = 0; o < t.length; o++) {
          var e = t[o];
          (e.enumerable = e.enumerable || !1),
            (e.configurable = !0),
            "value" in e && (e.writable = !0),
            Object.defineProperty(n, e.key, e);
        }
      }
      function f(n, t) {
        return (
          (f =
            Object.setPrototypeOf ||
            function (o, e) {
              return (o.__proto__ = e), o;
            }),
          f(n, t)
        );
      }
      function T(n, t) {
        if (t && (a(t) === "object" || typeof t == "function")) return t;
        if (t !== void 0)
          throw new TypeError(
            "Derived constructors may only return object or undefined"
          );
        return (function (o) {
          if (o === void 0)
            throw new ReferenceError(
              "this hasn't been initialised - super() hasn't been called"
            );
          return o;
        })(n);
      }
      function C(n) {
        return (
          (C = Object.setPrototypeOf
            ? Object.getPrototypeOf
            : function (t) {
                return t.__proto__ || Object.getPrototypeOf(t);
              }),
          C(n)
        );
      }
      var S = (function (n) {
        (function (r, s) {
          if (typeof s != "function" && s !== null)
            throw new TypeError(
              "Super expression must either be null or a function"
            );
          (r.prototype = Object.create(s && s.prototype, {
            constructor: { value: r, writable: !0, configurable: !0 },
          })),
            s && f(r, s);
        })(l, n);
        var t,
          o,
          e,
          i,
          g =
            ((e = l),
            (i = (function () {
              if (
                typeof Reflect > "u" ||
                !Reflect.construct ||
                Reflect.construct.sham
              )
                return !1;
              if (typeof Proxy == "function") return !0;
              try {
                return (
                  Boolean.prototype.valueOf.call(
                    Reflect.construct(Boolean, [], function () {})
                  ),
                  !0
                );
              } catch {
                return !1;
              }
            })()),
            function () {
              var r,
                s = C(e);
              if (i) {
                var h = C(this).constructor;
                r = Reflect.construct(s, arguments, h);
              } else r = s.apply(this, arguments);
              return T(this, r);
            });
        function l(r) {
          var s,
            h =
              arguments.length > 1 && arguments[1] !== void 0
                ? arguments[1]
                : "modal",
            I = arguments.length > 2 ? arguments[2] : void 0,
            K = arguments.length > 3 ? arguments[3] : void 0,
            G = arguments.length > 4 ? arguments[4] : void 0;
          c(this, l);
          var J = "animation-duration: ".concat(
            I.toSecs(I.animationDuration),
            ";"
          );
          return (
            ((s = g.call(this, document.body, d.ids.wrapper, null, J, I))[
              d.ids.confirmOk
            ] = K),
            (s[d.ids.confirmCancel] = G),
            (s.className = "".concat(d.prefix, "-").concat(h)),
            ["confirm", "async-block", "modal"].includes(h) || (h = "modal"),
            s.updateType(h),
            s.setInnerHtml(r),
            s.insert(),
            s
          );
        }
        return (
          (t = l),
          (o = [
            {
              key: "setInnerHtml",
              value: function (r) {
                var s = this.options.applyReplacements(r, this.type);
                switch (this.type) {
                  case "confirm":
                    var h = [
                      "<button class='"
                        .concat(d.klass.button, " ")
                        .concat(d.klass.successBtn, "'id='")
                        .concat(d.ids.confirmOk, "'>")
                        .concat(this.options.labels.confirmOk, "</button>"),
                    ];
                    this[d.ids.confirmCancel] !== !1 &&
                      h.push(
                        "<button class='"
                          .concat(d.klass.button, " ")
                          .concat(d.klass.cancelBtn, "'id='")
                          .concat(d.ids.confirmCancel, "'>")
                          .concat(
                            this.options.labels.confirmCancel,
                            "</button>"
                          )
                      ),
                      (s = ""
                        .concat(this.options.icon(this.type), "<div class='")
                        .concat(d.klass.title, "'>")
                        .concat(
                          this.options.label(this.type),
                          '</div><div class="'
                        )
                        .concat(d.klass.content, '">')
                        .concat(s, "</div><div class='")
                        .concat(d.klass.buttons, " ")
                        .concat(d.klass.buttons, "-")
                        .concat(h.length, "'>")
                        .concat(h.join(""), "</div>"));
                    break;
                  case "async-block":
                    s = ""
                      .concat(s, '<div class="')
                      .concat(d.klass.auraAnimation, '"></div>');
                }
                this.newNode.innerHTML = '<div class="'
                  .concat(d.klass.body, " ")
                  .concat(this.className, '">')
                  .concat(s, "</div>");
              },
            },
            {
              key: "keyupListener",
              value: function (r) {
                if (this.type === "async-block") return r.preventDefault();
                switch (r.code) {
                  case "Escape":
                    r.preventDefault(), this.delete();
                  case "Tab":
                    if (
                      (r.preventDefault(),
                      this.type !== "confirm" ||
                        this[d.ids.confirmCancel] === !1)
                    )
                      return !0;
                    var s = this.okBtn;
                    r.shiftKey
                      ? document.activeElement.id == d.ids.confirmOk &&
                        (s = this.cancelBtn)
                      : document.activeElement.id !== d.ids.confirmCancel &&
                        (s = this.cancelBtn),
                      s.focus();
                }
              },
            },
            {
              key: "afterInsert",
              value: function () {
                var r = this;
                switch (
                  ((this.listener = function (s) {
                    return r.keyupListener(s);
                  }),
                  window.addEventListener("keydown", this.listener),
                  this.type)
                ) {
                  case "async-block":
                    this.start = Date.now();
                    break;
                  case "confirm":
                    this.okBtn.focus(),
                      this.addEvent("click", function (s) {
                        if (s.target.nodeName !== "BUTTON") return !1;
                        r.delete(), r[s.target.id] && r[s.target.id]();
                      });
                    break;
                  default:
                    document.activeElement.blur(),
                      this.addEvent("click", function (s) {
                        s.target.id === r.newNode.id && r.delete();
                      });
                }
              },
            },
            {
              key: "afterDelete",
              value: function () {
                window.removeEventListener("keydown", this.listener);
              },
            },
            {
              key: "okBtn",
              get: function () {
                return document.getElementById(d.ids.confirmOk);
              },
            },
            {
              key: "cancelBtn",
              get: function () {
                return document.getElementById(d.ids.confirmCancel);
              },
            },
          ]) && m(t.prototype, o),
          l
        );
      })(j);
      function u(n) {
        return (
          (u =
            typeof Symbol == "function" && typeof Symbol.iterator == "symbol"
              ? function (t) {
                  return typeof t;
                }
              : function (t) {
                  return t &&
                    typeof Symbol == "function" &&
                    t.constructor === Symbol &&
                    t !== Symbol.prototype
                    ? "symbol"
                    : typeof t;
                }),
          u(n)
        );
      }
      function _(n, t) {
        if (!(n instanceof t))
          throw new TypeError("Cannot call a class as a function");
      }
      function k(n, t) {
        for (var o = 0; o < t.length; o++) {
          var e = t[o];
          (e.enumerable = e.enumerable || !1),
            (e.configurable = !0),
            "value" in e && (e.writable = !0),
            Object.defineProperty(n, e.key, e);
        }
      }
      var N = (function () {
        function n() {
          var e =
            arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
          _(this, n), (this.options = new L(e));
        }
        var t, o;
        return (
          (t = n),
          (o = [
            {
              key: "tip",
              value: function (e, i) {
                return this._addToast(e, "tip", i).el;
              },
            },
            {
              key: "info",
              value: function (e, i) {
                return this._addToast(e, "info", i).el;
              },
            },
            {
              key: "success",
              value: function (e, i) {
                return this._addToast(e, "success", i).el;
              },
            },
            {
              key: "warning",
              value: function (e, i) {
                return this._addToast(e, "warning", i).el;
              },
            },
            {
              key: "alert",
              value: function (e, i) {
                return this._addToast(e, "alert", i).el;
              },
            },
            {
              key: "async",
              value: function (e, i, g, l, r) {
                var s = this._addToast(l, "async", r);
                return this._afterAsync(e, i, g, r, s);
              },
            },
            {
              key: "confirm",
              value: function (e, i, g, l) {
                return this._addPopup(e, "confirm", l, i, g);
              },
            },
            {
              key: "asyncBlock",
              value: function (e, i, g, l, r) {
                var s = this._addPopup(l, "async-block", r);
                return this._afterAsync(e, i, g, r, s);
              },
            },
            {
              key: "modal",
              value: function (e, i, g) {
                return this._addPopup(e, i, g);
              },
            },
            {
              key: "closeToasts",
              value: function () {
                for (var e = this.container; e.firstChild; )
                  e.removeChild(e.firstChild);
              },
            },
            {
              key: "_addPopup",
              value: function (e, i, g, l, r) {
                return new S(e, i, this.options.override(g), l, r);
              },
            },
            {
              key: "_addToast",
              value: function (e, i, g, l) {
                g = this.options.override(g);
                var r = new V(e, i, g, this.container);
                return l
                  ? l instanceof S
                    ? l.delete().then(function () {
                        return r.insert();
                      })
                    : l.replace(r)
                  : r.insert();
              },
            },
            {
              key: "_afterAsync",
              value: function (e, i, g, l, r) {
                return e.then(
                  this._responseHandler(i, "success", l, r),
                  this._responseHandler(g, "alert", l, r)
                );
              },
            },
            {
              key: "_responseHandler",
              value: function (e, i, g, l) {
                var r = this;
                return function (s) {
                  switch (u(e)) {
                    case "undefined":
                    case "string":
                      var h = i === "alert" ? e || s : e;
                      r._addToast(h, i, g, l);
                      break;
                    default:
                      l.delete().then(function () {
                        e && e(s);
                      });
                  }
                };
              },
            },
            {
              key: "_createContainer",
              value: function () {
                return new j(
                  document.body,
                  x.ids.container,
                  "awn-".concat(this.options.position)
                ).insert().el;
              },
            },
            {
              key: "container",
              get: function () {
                return (
                  document.getElementById(x.ids.container) ||
                  this._createContainer()
                );
              },
            },
          ]) && k(t.prototype, o),
          n
        );
      })();
      return P;
    })();
  });
})(Y);
var oe = Y.exports;
const ie = Q(oe);
let M;
document.addEventListener("DOMContentLoaded", () => ae());
async function ae() {
  let p = new ie(window);
  const E = document.getElementById("consoleBox"),
    O = document.getElementById("bin"),
    P = document.getElementById("save"),
    A = document.getElementById("clear_logs"),
    w = document.getElementById("toggle");
  if (E) {
    let L = function () {
      y.forEach((b, v) => {
        let x = b.indexOf(":"),
          d = b.indexOf(":", x + 1);
        if (x !== -1 && d !== -1) {
          let $ = b.substring(0, x),
            F = b.substring(x + 1, d),
            j = b.substring(d + 1),
            B = document.createElement("div");
          (B.style.background = `linear-gradient(145deg, #${$}, #${F})`),
            (B.style.backgroundClip = "text"),
            (B.style.webkitBackgroundClip = "text"),
            (B.textContent = j),
            E.appendChild(B);
        } else E.innerHTML += `${b}<br/>`;
      });
    };
    var D = L;
    let y = (await ne("logs")) || [];
    y.unshift("b890ff:6f33cc:Welcome to Aura Bypasser!"),
      L(),
      R.storage.onChanged.addListener((b, v) => {
        var x;
        (x = b == null ? void 0 : b.logs) != null &&
          x.newValue &&
          ((y = b.logs.newValue),
          y.length < 9 && y.unshift("b890ff:6f33cc:Welcome to Aura Bypasser!"),
          (E.innerHTML = ""),
          L());
      });
  }
  if (
    (O &&
      ((M = await se("bin")),
      (O.value = M),
      O.addEventListener("input", () => {
        M = O.value;
      })),
    P &&
      P.addEventListener("click", (y) => {
        y.preventDefault(),
          p.async(R.storage.local.set({ bin: M }), () => {
            R.runtime.sendMessage({
              action: "executeScript",
              bin: M
                ? M.trim().split(`
`)
                : void 0,
            }),
              p.success("Saved!");
          });
      }),
    A &&
      A.addEventListener("click", (y) => {
        y.preventDefault(),
          p.async(R.storage.local.set({ logs: [] }), () => {
            p.success("Cleared Logs!");
          });
      }),
    w)
  ) {
    let y = await re("toggle");
    (w.checked = y),
      w.addEventListener("change", () => {
        (y = w.checked),
          p.async(R.storage.local.set({ toggle: y }), async () => {
            y
              ? await R.runtime.sendMessage({
                  action: "executeScript",
                  bin: M
                    ? M.trim().split(`
`)
                    : void 0,
                })
              : await R.runtime.sendMessage({ action: "disable" }),
              p.success(`Turned ${y ? "on" : "off"} bypasser!`);
          });
      });
  }
}
